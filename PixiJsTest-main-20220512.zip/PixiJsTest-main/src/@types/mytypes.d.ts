// import * as PIXI from "pixi.js";
// declare interface Window {
//     PIXI: PIXI;
// }

interface Window {
    webkitAudioContext: typeof AudioContext;
}
interface OscillatorNode {
    noteOn(): (when?: number) => void;
    noteOff(): (when?: number) => void;
}

// declare class MyCubismModel {
//     /**
//      * モデルのパラメータの更新
//      */
//     update(): void;
//     /**
//      * キャンバスの幅を取得する
//      */
//     getCanvasWidth(): number;
//     /**
//      * キャンバスの高さを取得する
//      */
//     getCanvasHeight(): number;
//     /**
//      * パラメータを保存する
//      */
//     saveParameters(): void;
//     /**
//      * モデルを取得
//      */
//     getModel(): Live2DCubismCore.Model;
//     /**
//      * パーツのインデックスを取得
//      * @param partId パーツのID
//      * @return パーツのインデックス
//      */
//     getPartIndex(partId: string): number;
//     /**
//      * パーツの個数の取得
//      * @return パーツの個数
//      */
//     getPartCount(): number;
//     /**
//      * パーツの不透明度の設定(Index)
//      * @param partIndex パーツのインデックス
//      * @param opacity 不透明度
//      */
//     setPartOpacityByIndex(partIndex: number, opacity: number): void;
//     /**
//      * パーツの不透明度の設定(Id)
//      * @param partId パーツのID
//      * @param opacity パーツの不透明度
//      */
//     setPartOpacityById(partId: string, opacity: number): void;
//     /**
//      * パーツの不透明度の取得(index)
//      * @param partIndex パーツのインデックス
//      * @return パーツの不透明度
//      */
//     getPartOpacityByIndex(partIndex: number): number;
//     /**
//      * パーツの不透明度の取得(id)
//      * @param partId パーツのＩｄ
//      * @return パーツの不透明度
//      */
//     getPartOpacityById(partId: string): number;
//     /**
//      * パラメータのインデックスの取得
//      * @param パラメータID
//      * @return パラメータのインデックス
//      */
//     getParameterIndex(parameterId: string): number;
//     /**
//      * パラメータの個数の取得
//      * @return パラメータの個数
//      */
//     getParameterCount(): number;
//     /**
//      * パラメータの最大値の取得
//      * @param parameterIndex パラメータのインデックス
//      * @return パラメータの最大値
//      */
//     getParameterMaximumValue(parameterIndex: number): number;
//     /**
//      * パラメータの最小値の取得
//      * @param parameterIndex パラメータのインデックス
//      * @return パラメータの最小値
//      */
//     getParameterMinimumValue(parameterIndex: number): number;
//     /**
//      * パラメータのデフォルト値の取得
//      * @param parameterIndex パラメータのインデックス
//      * @return パラメータのデフォルト値
//      */
//     getParameterDefaultValue(parameterIndex: number): number;
//     /**
//      * パラメータの値の取得
//      * @param parameterIndex    パラメータのインデックス
//      * @return パラメータの値
//      */
//     getParameterValueByIndex(parameterIndex: number): number;
//     /**
//      * パラメータの値の取得
//      * @param parameterId    パラメータのID
//      * @return パラメータの値
//      */
//     getParameterValueById(parameterId: string): number;
//     /**
//      * パラメータの値の設定
//      * @param parameterIndex パラメータのインデックス
//      * @param value パラメータの値
//      * @param weight 重み
//      */
//     setParameterValueByIndex(parameterIndex: number, value: number, weight?: number): void;
//     /**
//      * パラメータの値の設定
//      * @param parameterId パラメータのID
//      * @param value パラメータの値
//      * @param weight 重み
//      */
//     setParameterValueById(parameterId: string, value: number, weight?: number): void;
//     /**
//      * パラメータの値の加算(index)
//      * @param parameterIndex パラメータインデックス
//      * @param value 加算する値
//      * @param weight 重み
//      */
//     addParameterValueByIndex(parameterIndex: number, value: number, weight?: number): void;
//     /**
//      * パラメータの値の加算(id)
//      * @param parameterId パラメータＩＤ
//      * @param value 加算する値
//      * @param weight 重み
//      */
//     addParameterValueById(parameterId: any, value: number, weight?: number): void;
//     /**
//      * パラメータの値の乗算
//      * @param parameterId パラメータのID
//      * @param value 乗算する値
//      * @param weight 重み
//      */
//     multiplyParameterValueById(parameterId: string, value: number, weight?: number): void;
//     /**
//      * パラメータの値の乗算
//      * @param parameterIndex パラメータのインデックス
//      * @param value 乗算する値
//      * @param weight 重み
//      */
//     multiplyParameterValueByIndex(parameterIndex: number, value: number, weight?: number): void;
//     getDrawableIds(): string[];
//     /**
//      * Drawableのインデックスの取得
//      * @param drawableId DrawableのID
//      * @return Drawableのインデックス
//      */
//     getDrawableIndex(drawableId: string): number;
//     /**
//      * Drawableの個数の取得
//      * @return drawableの個数
//      */
//     getDrawableCount(): number;
//     /**
//      * DrawableのIDを取得する
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableのID
//      */
//     getDrawableId(drawableIndex: number): string;
//     /**
//      * Drawableの描画順リストの取得
//      * @return Drawableの描画順リスト
//      */
//     getDrawableRenderOrders(): Int32Array;
//     /**
//      * Drawableのテクスチャインデックスリストの取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableのテクスチャインデックスリスト
//      */
//     getDrawableTextureIndices(drawableIndex: number): number;
//     /**
//      * DrawableのVertexPositionsの変化情報の取得
//      *
//      * 直近のCubismModel.update関数でDrawableの頂点情報が変化したかを取得する。
//      *
//      * @param   drawableIndex   Drawableのインデックス
//      * @retval  true    Drawableの頂点情報が直近のCubismModel.update関数で変化した
//      * @retval  false   Drawableの頂点情報が直近のCubismModel.update関数で変化していない
//      */
//     getDrawableDynamicFlagVertexPositionsDidChange(drawableIndex: number): boolean;
//     /**
//      * Drawableの頂点インデックスの個数の取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableの頂点インデックスの個数
//      */
//     getDrawableVertexIndexCount(drawableIndex: number): number;
//     /**
//      * Drawableの頂点の個数の取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableの頂点の個数
//      */
//     getDrawableVertexCount(drawableIndex: number): number;
//     /**
//      * Drawableの頂点リストの取得
//      * @param drawableIndex drawableのインデックス
//      * @return drawableの頂点リスト
//      */
//     getDrawableVertices(drawableIndex: number): Float32Array;
//     /**
//      * Drawableの頂点インデックスリストの取得
//      * @param drarableIndex Drawableのインデックス
//      * @return drawableの頂点インデックスリスト
//      */
//     getDrawableVertexIndices(drawableIndex: number): Uint16Array;
//     /**
//      * Drawableの頂点リストの取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableの頂点リスト
//      */
//     getDrawableVertexPositions(drawableIndex: number): Float32Array;
//     /**
//      * Drawableの頂点のUVリストの取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableの頂点UVリスト
//      */
//     getDrawableVertexUvs(drawableIndex: number): Float32Array;
//     /**
//      * Drawableの不透明度の取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableの不透明度
//      */
//     getDrawableOpacity(drawableIndex: number): number;
//     /**
//      * Drawableのカリング情報の取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableのカリング情報
//      */
//     getDrawableCulling(drawableIndex: number): boolean;
//     /**
//      * Drawableのブレンドモードを取得
//      * @param drawableIndex Drawableのインデックス
//      * @return drawableのブレンドモード
//      */
//     getDrawableBlendMode(drawableIndex: number): CubismBlendMode;
//     /**
//      * Drawableのマスクの反転使用の取得
//      *
//      * Drawableのマスク使用時の反転設定を取得する。
//      * マスクを使用しない場合は無視される。
//      *
//      * @param drawableIndex Drawableのインデックス
//      * @return Drawableの反転設定
//      */
//     getDrawableInvertedMaskBit(drawableIndex: number): boolean;
//     /**
//      * Drawableのクリッピングマスクリストの取得
//      * @return Drawableのクリッピングマスクリスト
//      */
//     getDrawableMasks(): Int32Array[];
//     /**
//      * Drawableのクリッピングマスクの個数リストの取得
//      * @return Drawableのクリッピングマスクの個数リスト
//      */
//     getDrawableMaskCounts(): Int32Array;
//     /**
//      * クリッピングマスクの使用状態
//      *
//      * @return true クリッピングマスクを使用している
//      * @return false クリッピングマスクを使用していない
//      */
//     isUsingMasking(): boolean;
//     /**
//      * Drawableの表示情報を取得する
//      *
//      * @param drawableIndex Drawableのインデックス
//      * @return true Drawableが表示
//      * @return false Drawableが非表示
//      */
//     getDrawableDynamicFlagIsVisible(drawableIndex: number): boolean;
//     /**
//      * DrawableのDrawOrderの変化情報の取得
//      *
//      * 直近のCubismModel.update関数でdrawableのdrawOrderが変化したかを取得する。
//      * drawOrderはartMesh上で指定する0から1000の情報
//      * @param drawableIndex drawableのインデックス
//      * @return true drawableの不透明度が直近のCubismModel.update関数で変化した
//      * @return false drawableの不透明度が直近のCubismModel.update関数で変化している
//      */
//     getDrawableDynamicFlagVisibilityDidChange(drawableIndex: number): boolean;
//     /**
//      * Drawableの不透明度の変化情報の取得
//      *
//      * 直近のCubismModel.update関数でdrawableの不透明度が変化したかを取得する。
//      *
//      * @param drawableIndex drawableのインデックス
//      * @return true Drawableの不透明度が直近のCubismModel.update関数で変化した
//      * @return false Drawableの不透明度が直近のCubismModel.update関数で変化してない
//      */
//     getDrawableDynamicFlagOpacityDidChange(drawableIndex: number): boolean;
//     /**
//      * Drawableの描画順序の変化情報の取得
//      *
//      * 直近のCubismModel.update関数でDrawableの描画の順序が変化したかを取得する。
//      *
//      * @param drawableIndex Drawableのインデックス
//      * @return true Drawableの描画の順序が直近のCubismModel.update関数で変化した
//      * @return false Drawableの描画の順序が直近のCubismModel.update関数で変化してない
//      */
//     getDrawableDynamicFlagRenderOrderDidChange(drawableIndex: number): boolean;
//     /**
//      * 保存されたパラメータの読み込み
//      */
//     loadParameters(): void;
//     /**
//      * 初期化する
//      */
//     initialize(): void;
//     /**
//      * コンストラクタ
//      * @param model モデル
//      */
//     constructor(model: Live2DCubismCore.Model);
//     /**
//      * デストラクタ相当の処理
//      */
//     release(): void;
//     private _notExistPartOpacities;
//     private _notExistPartId;
//     private _notExistParameterValues;
//     private _notExistParameterId;
//     private _savedParameters;
//     private _model;
//     private _parameterValues;
//     private _parameterMaximumValues;
//     private _parameterMinimumValues;
//     private _partOpacities;
//     private _parameterIds;
//     private _partIds;
//     private _drawableIds;
// }
