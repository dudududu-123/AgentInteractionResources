export type ModelPosition = { boxWidth: number; boxHeight: number; modelScale: number; modelX: number; modelY: number };
